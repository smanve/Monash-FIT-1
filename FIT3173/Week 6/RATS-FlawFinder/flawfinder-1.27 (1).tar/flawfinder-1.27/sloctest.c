/* This is a test.  Should produce 6 SLOC.
 */
#include <stdio.h>
#define HI 10

main() {
  a = 1; /* hi */
  "hi"
}
